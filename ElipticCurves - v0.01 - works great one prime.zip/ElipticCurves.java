/*
https://youtu.be/4dyytPboqvE?t=834
13:54 Eliptic Curves:
fancy name for equations in 2 variables x and y where
one variable appears in degree 3 (cube) and the other appears in degree 2 (square).

Example: y^2 + y = x^3 - x^2

y^2 = highest power of y = a square
x^3 - highest power of x = a cube

What are the solutions for x and y where x and y are both integers ?
What are the solutions for x and y where x and y are both real numbers ?
What are the solutions for x and y where x and y are both complex numbers [i = sqrt(-1)] ?
For complex numbers, the solutions form a torus - like a donut - a Rhieman Surface.

For this equation, we are interested in solutions for x and y where x and y are both integers and we are modulo a prime number ?
e.g. 5
So, x and y are integers are both >= 0 and < 5.
and
   (y^2 + y) MOD 5 = (x^3 - x^2) MOD 5

e.g. If the equations yielded this then this would be a solution:  -5 MOD 5 = 20 MOD 5

*/

public class ElipticCurves
{
   public static boolean elipticCurveEquation1 (int prime, int x, int y, boolean displayResult)
   {
      // Ref: 18:30 in video: https://www.youtube.com/watch?v=4dyytPboqvE

      // y^2 + y = x^3 - x^2
      int LHS = (y * y + y);
      int RHS = (x * x * x - x * x);

      boolean result = (LHS % prime == RHS % prime);

      if ((result == true) && (displayResult == true) )
      {
         if ((LHS == 0) && (RHS == 0) )
            System.out.println ("x = " + x + ", y = " + y + "  (both sides = 0)");
         else
            System.out.println ("x = " + x + ", y = " + y + "  (LHS = " + LHS + ", RHS = " + RHS + ")");
      }

      return result;
   }

   public static void main(String[] args)
   {
      int prime = 5;   // Must be a Prime Number
      /*
      int modulo = 11;  // Must be a Prime Number
      int modulo = 13;  // Must be a Prime Number
      int modulo = 111; // Must be a Prime Number
      int modulo = 133; // Must be a Prime Number
      */

      int solutionsFound = 0;

      for (int y = 0; y < prime; y++)
      {
         for (int x = 0; x < prime; x++)
         {
            boolean result = elipticCurveEquation1 (prime, x, y, true);

            if (result == true)
               solutionsFound++;

         }
      }

      System.out.println ();
      System.out.println (String.format ("%15s", "Prime")         + "  " +
                          String.format ("%15s", "Num Solutions") + "  " +
                          String.format ("%15s", "Difference") );

      System.out.println (String.format ("%15s", "---------------") + "  " +
                          String.format ("%15s", "---------------") + "  " +
                          String.format ("%15s", "---------------") );

      System.out.println (String.format ("%,15d", prime)           + "  " +
                          String.format ("%,15d", solutionsFound)  + "  " +
                          String.format ("%,15d", (prime - solutionsFound) ) );

      System.out.println ();
   }
}